\setcounter{tocdepth}{3}

\phantomsection
# Table Of Contents {.unnumbered}

\tableofcontents