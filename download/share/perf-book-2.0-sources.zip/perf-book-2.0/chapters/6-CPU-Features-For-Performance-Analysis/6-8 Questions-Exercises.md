## Questions and Exercises {.unlisted .unnumbered}

\markright{Questions and Exercises}

1. Name the four level-1 categories in the TMA performance methodology.
2. What are the benefits of hardware event-based sampling?
3. What is a performance event skid?
4. Study performance analysis features available on the CPU inside the machine you use for development/benchmarking.
